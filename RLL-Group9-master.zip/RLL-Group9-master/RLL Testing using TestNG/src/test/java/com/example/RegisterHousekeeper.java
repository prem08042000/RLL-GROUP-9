package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RegisterHousekeeper {
	
	WebDriver wd=null;
	@BeforeTest
	public void intiate() {
		System.out.println("config intiated");
		//register the webdriver =>browser vendor 
				WebDriverManager.edgedriver().setup();
				//creating an object to the object
				 wd=new EdgeDriver();
				//maximize the browser
				wd.manage().window().maximize();
				
	}
  @Test
  public void feedback() throws InterruptedException {
	  
	  

	  wd.get("http://localhost:4200/Adminlogin");
	  wd.findElement(By.cssSelector("#EmailInput")).sendKeys("admin1");
	  wd.findElement(By.cssSelector("#PasswordInput")).sendKeys("admin123");
	
	  
	  wd.findElement(By.xpath("/html/body/app-root/app-login/div/div/div[2]/form/div/div[1]/button")).click();
	  
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("//button[contains(.,' Register Housekeeper')]")).click();
	  // /html/body/app-root/app-register-housekeeper/app-navbar/div[1]/button[5]
	  // /html/body/app-root/app-register-housekeeper/app-navbar/div[1]/button[5]
	  wd.findElement(By.xpath("/html/body/app-root/app-register-housekeeper/div[1]/form/div[1]/input")).sendKeys("Mn");
	  wd.findElement(By.xpath("//*[@id=\"inputRoom\"]")).sendKeys("2");
	  wd.findElement(By.xpath("/html/body/app-root/app-register-housekeeper/div[1]/form/div[3]/button")).click();
  }
  
  @AfterTest
  public void  derefer() {
		System.out.println("wd closed");
		wd.close();
	}
  
  
}